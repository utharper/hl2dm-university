                                  _
                                 | |__  _   _                        
                                 | '_ \| | | |                       
                                 | |_) | |_| |			     
                                 |_.__/ \__, |			     
                       ____      _     _|___/                        
                      / ___|_ __(_)___| |_(_) __ _ _ __              
                     | |   | '__| / __| __| |/ _` | '_ \	     
                     | |___| |  | \__ \ |_| | (_| | | | |	     
                      \____|_|  |_|___/\__|_|\__,_|_| |_|   	     
                     / _ \ _ __ | |_(_)_   _____ _ __ ___	     
                    | | | | '_ \| __| \ \ / / _ \ '__/ _ \	     
                    | |_| | | | | |_| |\ V /  __/ | | (_) |	     
                     \___/|_| |_|\__|_| \_/ \___|_|  \___/	     
								     
a.k.a|  onty.							      
								     
[]======================================================================================================================================[]

  =======================
{}------- Install -------{}
  =======================

To install whatever color you wish to use, just place the clientscheme.res file of the color you want, in the following directory.

"c:\Program Files\Steam\Steamapps\*YOUR-ACCOUNT-NAME-HERE*\Half Life 2 Deathmatch\hl2mp\resource"

  =======================
{}------ Uninstall ------{}
  =======================

To uninstall the crosshair color, and going back to the default one, just erase the clientscheme.res file (or rename it) from the directory already mentioned.

  =======================
{}---- Translucency -----{}
  =======================

The difference between the additive and non additive crosshairs, is that the additive ones are translucent, and the non-additive aren't.
This is just personal preference.

  =======================
{}---- Outlined -----{}
  =======================

The outlined crosshairs have a black border around it. Same as above, it's mostly personal preference, although when combined with a shiny color it
provides contrast on both bright and dark backgrounds, which can be pretty useful.